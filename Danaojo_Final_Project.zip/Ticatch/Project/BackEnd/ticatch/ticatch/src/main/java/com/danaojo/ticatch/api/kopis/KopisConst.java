package com.danaojo.ticatch.api.kopis;

public class KopisConst {
	// KOPIS_API_KEY
	public static final String KOPIS_API_KEY = "59d9d3d10bfb4d81865cb695b2cca643";
}