package com.danaojo.ticatch.detail.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class SaveDTO {
	private int seq_save_id;
	private String user_id;
	private Long seq_pfjoin_id;
}
