package com.danaojo.ticatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
