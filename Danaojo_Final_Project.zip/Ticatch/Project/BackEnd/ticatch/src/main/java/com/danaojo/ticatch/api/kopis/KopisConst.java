package com.danaojo.ticatch.api.kopis;

public class KopisConst {
	// KOPIS_API_KEY
	public static final String KOPIS_API_KEY = "59d9d3d10bfb4d81865cb695b2cca643";
	
	// 다른 사람들 데이터 필요한데 한도라서 안된면 키만 바꿔서 다시 해보기 (42개정도 데이터 들어와짐 100개 하면)
	
	// 예매 및 결제 개발자가 발급한거
	// 382faa554511471fb95c1b6fbbe64f13
	
	// 마이페이지 개발자가 발급한거
	// 59d9d3d10bfb4d81865cb695b2cca643
}