package com.danaojo.ticatch.detail.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class PFJOINDTO {
	private String seq_pfjoin_id;
	private String fd_addr;
	private String fd_fatitude;
	private String fd_longitude;
	private String fd_phone;
	private String p_end_date;
	private String p_genre;
	private String p_id;
	private String p_poster;
	private String p_start_date;
	private String p_title;
	private String pd_cast;
	private String pd_hall_name;
	private String pd_img;
	private String pd_location;
	private String pd_runtime;
	private String seatprice;
	private String pd_time;
	private String pl_location_gun;
	private String pl_location_sido;
	
}
