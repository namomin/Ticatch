---
name: Issue Template
about: 버그 리포트 생성 시 사용하시면 됩니다.
title: "[BUG] 제목 수정하시면 됩니다."
labels: ''
assignees: ''

---

##  Issue 한 줄 요약

이슈를 한줄로 요약해주세요.

##  Issue 세부 내용

무슨 이슈인가요?

##  기대 결과

어떤 결과물을 원하시나요?

##  스크린샷

이슈에 해당하는 부분을 보여주세요.
